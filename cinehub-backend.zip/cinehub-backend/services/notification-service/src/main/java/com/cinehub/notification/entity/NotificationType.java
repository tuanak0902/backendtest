package com.cinehub.notification.entity;

public enum NotificationType {
    BOOKING_TICKET,
    PROMOTION
}

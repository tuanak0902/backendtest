package com.cinehub.movie.entity;

public enum MovieStatus {
    UPCOMING,
    NOW_PLAYING,
    ARCHIVED
}

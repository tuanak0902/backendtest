package com.cinehub.review.entity;

public enum ReviewStatus {
    VISIBLE,
    HIDDEN
}

package com.cinehub.promotion.entity;

public enum DiscountType {
    PERCENTAGE, // Chiết khấu theo phần trăm
    FIXED_AMOUNT // Chiết khấu theo số tiền cố định
}
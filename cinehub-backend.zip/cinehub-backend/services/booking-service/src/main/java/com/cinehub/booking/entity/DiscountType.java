package com.cinehub.booking.entity;

public enum DiscountType {
    PERCENTAGE,
    FIXED_AMOUNT
}
package com.cinehub.fnb.entity;

public enum FnbOrderStatus {
    PENDING,
    PAID,
    CANCELLED
}

package com.cinehub.payment.entity;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED,
    REFUNDED,
    EXPIRED
}
